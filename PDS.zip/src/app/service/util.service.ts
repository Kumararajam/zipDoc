import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UtilService {
  showRequest: boolean = false;
  showMapperConfig: boolean = false;
  showProductConfig: boolean = false;
  showAssignService: boolean = false;
  showGetAttribute: boolean = false;
  showAssignedRequest: boolean = false;
  constructor() { }
  openRequest() {
    this.showRequest = true;   
  }
  closeRequest() {
    this.showRequest = false;
    if(this.showAssignService){
      this.showAssignedRequest = false;
    }
  }
  openMapperConfig() {
    this.showMapperConfig = !this.showMapperConfig;
  }
  closeMapperConfig() {
    this.showMapperConfig = !this.showMapperConfig;
  }
  openProductConfig() {
    this.showProductConfig = !this.showProductConfig;
  }
  closeProductConfig() {
    this.showProductConfig = !this.showProductConfig;
  }
  openAssignService() {
    this.showAssignService = true;
  }
  closeAssignService() {
    this.showAssignService = false;
    this.showGetAttribute = false;
    this.showAssignedRequest = false;
  }
  openGetAttribute() {
    this.showGetAttribute = !this.showGetAttribute;
  }
  closeGetAttribute() {
    this.showGetAttribute = !this.showGetAttribute;
  }
  openAssignedRequest() {
    this.showAssignedRequest = true;
    this.showRequest = false;
  }
  closeAssignedRequest() {
    this.showAssignedRequest = false;
  }
  stopPropagate() {
    event.stopPropagation();
  }
}
