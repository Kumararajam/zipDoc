import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

// Material Components 
import {MatInputModule,MatSelectModule} from '@angular/material';
//primeng components
import {AccordionModule} from 'primeng/accordion';
import {DragDropModule} from 'primeng/dragdrop';
//Custom Components
import { HeaderComponent } from './components/shared/header/header.component';
import { LayoutComponent } from './components/layout/layout.component';
import { ServiceRegistrationComponent } from './components/service-registration/service-registration.component';
import { CreateProductComponent } from './components/create-product/create-product.component';
import { ProductConfigComponent } from './components/create-product/product-config/product-config.component';
import { ToolPalatteComponent } from './components/create-product/tool-palatte/tool-palatte.component';
import { GetAttributeComponent } from './components/create-product/get-attribute/get-attribute.component';
import { AssignServiceComponent } from './components/create-product/assign-service/assign-service.component';
import { MapperConfigComponent } from './components/create-product/mapper-config/mapper-config.component';
import { RequestSliderComponent } from './components/shared/request-slider/request-slider.component';
import { MapperComponent } from './components/mapper/mapper.component';
import { InputFieldComponent } from './components/mapper/input-field/input-field.component';
import { OutputFieldComponent } from './components/mapper/output-field/output-field.component';
import { MapAndRuleComponent } from './components/mapper/map-and-rule/map-and-rule.component';
import { FormsModule } from '@angular/forms';
import { UtilService } from './service/util.service';
import { CarService } from './components/mapper/map-and-rule/carservice';
// import { HttpClient } from '@angular/common/http';
import { HttpClientModule }    from '@angular/common/http';
import { TableModule } from 'primeng/table';
import { CredentialsComponent } from './components/service-registration/credentials/credentials.component';
@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    MatInputModule,
    MatSelectModule,
    AccordionModule,
    DragDropModule,
    HttpClientModule,
    FormsModule,
    TableModule
  ], 
  declarations: [
    AppComponent,
    HeaderComponent,
    LayoutComponent,
    ServiceRegistrationComponent,
    CreateProductComponent,
    ProductConfigComponent,
    ToolPalatteComponent,
    GetAttributeComponent,
    AssignServiceComponent,
    MapperConfigComponent,
    RequestSliderComponent,
    MapperComponent,
    InputFieldComponent,
    OutputFieldComponent,
    MapAndRuleComponent,
    CredentialsComponent
  ],
  providers: [UtilService, CarService],
  bootstrap: [AppComponent]
})
export class AppModule { }
