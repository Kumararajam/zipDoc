import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './components/layout/layout.component';
import { ServiceRegistrationComponent } from './components/service-registration/service-registration.component';
import { CreateProductComponent } from './components/create-product/create-product.component';
import { MapperComponent } from './components/mapper/mapper.component';

const routes: Routes = [
  { path: '', component: ServiceRegistrationComponent },
  { path: 'serviceRegistration', component: ServiceRegistrationComponent },  
  { path: 'createProduct', component: CreateProductComponent },
  { path: 'mapper', component: MapperComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})


export class AppRoutingModule {
}
