import { Component, OnInit } from '@angular/core';
import { UtilService } from '../../service/util.service';

@Component({
  selector: 'app-service-registration',
  templateUrl: './service-registration.component.html',
  styleUrls: ['./service-registration.component.scss']
})
export class ServiceRegistrationComponent implements OnInit {
  
  constructor(private utilObject: UtilService) { }

  ngOnInit() {
  }


}
