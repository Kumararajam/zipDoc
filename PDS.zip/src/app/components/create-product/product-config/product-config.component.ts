import { Component, OnInit } from '@angular/core';
import { UtilService } from '../../../service/util.service';

@Component({
  selector: 'app-product-config',
  templateUrl: './product-config.component.html'
})
export class ProductConfigComponent implements OnInit {

  constructor(private utilObject: UtilService) { }

  ngOnInit() {
  }

}
