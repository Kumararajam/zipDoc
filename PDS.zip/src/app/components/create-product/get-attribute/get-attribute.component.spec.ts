import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetAttributeComponent } from './get-attribute.component';

describe('GetAttributeComponent', () => {
  let component: GetAttributeComponent;
  let fixture: ComponentFixture<GetAttributeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetAttributeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetAttributeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
