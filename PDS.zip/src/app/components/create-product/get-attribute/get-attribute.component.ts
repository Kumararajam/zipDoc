import { Component, OnInit } from '@angular/core';
import { UtilService } from '../../../service/util.service';

@Component({
  selector: 'app-get-attribute',
  templateUrl: './get-attribute.component.html'
})
export class GetAttributeComponent implements OnInit {

  constructor(private utilObject: UtilService) { }

  ngOnInit() {
  }

}
