import { Component, OnInit } from '@angular/core';
import { UtilService } from '../../../service/util.service';


@Component({
  selector: 'app-mapper-config',
  templateUrl: './mapper-config.component.html'
})
export class MapperConfigComponent implements OnInit {
  // cars: SelectItem[];

 
  constructor(private utilObject: UtilService) {
    // this.cars = [
    //   { label: 'Audi', value: 'Audi' },
    //   { label: 'BMW', value: 'BMW' },
    //   { label: 'Fiat', value: 'Fiat' },
    //   { label: 'Ford', value: 'Ford' },
    //   { label: 'Honda', value: 'Honda' },
    //   { label: 'Jaguar', value: 'Jaguar' },
    //   { label: 'Mercedes', value: 'Mercedes' },
    //   { label: 'Renault', value: 'Renault' },
    //   { label: 'VW', value: 'VW' },
    //   { label: 'Volvo', value: 'Volvo' }
    // ];
  }

  ngOnInit() {
  }

}
