import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MapperConfigComponent } from './mapper-config.component';

describe('MapperConfigComponent', () => {
  let component: MapperConfigComponent;
  let fixture: ComponentFixture<MapperConfigComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MapperConfigComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MapperConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
