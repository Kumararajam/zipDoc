import { Component, OnInit } from '@angular/core';
import { UtilService } from '../../../service/util.service';

@Component({
  selector: 'app-tool-palatte',
  templateUrl: './tool-palatte.component.html'
})
export class ToolPalatteComponent implements OnInit {

  constructor(private utilObject: UtilService) { }

  ngOnInit() {
  }
}
