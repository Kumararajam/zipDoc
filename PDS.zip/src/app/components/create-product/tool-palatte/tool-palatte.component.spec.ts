import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ToolPalatteComponent } from './tool-palatte.component';

describe('ToolPalatteComponent', () => {
  let component: ToolPalatteComponent;
  let fixture: ComponentFixture<ToolPalatteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ToolPalatteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ToolPalatteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
