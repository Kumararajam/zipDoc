import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { UtilService } from '../../service/util.service';

@Component({
  selector: 'app-create-product',
  templateUrl: './create-product.component.html',
  styleUrls: ['./create-product.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CreateProductComponent implements OnInit {
  constructor(private utilObject: UtilService) { }

  ngOnInit() {
  }
  closeMapper(){
    this.utilObject.closeMapperConfig();
  }
}
