import { Component, OnInit } from '@angular/core';
import { UtilService } from '../../../service/util.service';

@Component({
  selector: 'app-assign-service',
  styleUrls: ['./assign-service.component.scss'],
  templateUrl: './assign-service.component.html'
})
export class AssignServiceComponent implements OnInit {

  constructor(private utilObject: UtilService) { }

  ngOnInit() {
  }

}
