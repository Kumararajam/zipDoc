import { Component, OnInit } from '@angular/core';
import { UtilService } from '../../../service/util.service';

@Component({
  selector: 'app-request-slider',
  templateUrl: './request-slider.component.html',
  styleUrls: ['./request-slider.component.scss']
})
export class RequestSliderComponent implements OnInit {

  constructor(private utilObject: UtilService) { }

  ngOnInit() {
  }

}
