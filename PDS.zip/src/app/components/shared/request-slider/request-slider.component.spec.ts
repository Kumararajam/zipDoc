import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestSliderComponent } from './request-slider.component';

describe('RequestSliderComponent', () => {
  let component: RequestSliderComponent;
  let fixture: ComponentFixture<RequestSliderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RequestSliderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestSliderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
