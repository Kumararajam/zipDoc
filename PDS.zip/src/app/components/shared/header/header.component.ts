import { Component, OnInit } from '@angular/core';
import { UtilService } from '../../../service/util.service';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  public location = '';
  currentUrl:String;
  showMenuHeader:Boolean = false;
  constructor(private utilObject: UtilService, private router: Router) {

    router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.currentUrl = event.url;
        if(this.currentUrl == "/createProduct"){
          this.showMenuHeader = true;
        }
        else{
          this.showMenuHeader = false;
        }
      }
    });
  }

  ngOnInit() {
  }

}
