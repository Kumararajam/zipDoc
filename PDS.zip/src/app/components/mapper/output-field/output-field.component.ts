import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-output-field',
  templateUrl: './output-field.component.html'
})
export class OutputFieldComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
