import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-mapper',
  templateUrl: './mapper.component.html',
  styleUrls: ['./mapper.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MapperComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
