import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MapAndRuleComponent } from './map-and-rule.component';

describe('MapAndRuleComponent', () => {
  let component: MapAndRuleComponent;
  let fixture: ComponentFixture<MapAndRuleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MapAndRuleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MapAndRuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
